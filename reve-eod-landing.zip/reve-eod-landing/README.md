# Rêve EOD Reports — landing page

Reskinned to the Rêve Design System (tokens pulled from `claude/build_report_template.py`
in the Daily TC Report project — same palette, type, and radius scale used in the
production email report).

## What changed from the original draft

- **Color** — swapped the placeholder pink/coral for the actual token set: Noir
  `#0F1011`, Pearl `#F6D9D4`, Purple `#5C50A1` (heading accent), plus the functional
  Green `#1B7A3D` for the "connected" status dot. Coral (`#EE8172`) is used only inside
  the logo mark, not as UI chrome — that matches how the report template treats it
  ("brand accent, reserved for the logo").
- **Logo** — replaced the "RÊVE" text wordmark with the real tricolor logo asset
  (`assets/reve-logo-white.png`, sourced from the Design System project — the
  white-text version, confirmed to render correctly on the `#0F1011` header).
- **Radius & shadow** — cards and info boxes now use the design system's `4px`
  card radius and `0 4px 14px rgba(15,16,17,.08)` shadow instead of the heavier
  20px/45px values in the draft. The eyebrow badge keeps a pill radius (999px),
  which matches the token for pills/badges.
- **Type** — font stacks now match the system exactly: `Hauora` for body/UI text,
  `Batusa`/`Didot`/Georgia for the big display heading and card title.
- **Favicon** — generated from the coral roofline glyph in the logo mark, since the
  circular "REVE REALTORS" badge assets don't read cleanly at 16–32px.

## Fonts — action needed before this looks "on-brand" everywhere

`Hauora` and `Batusa` are licensed brand fonts, not public Google Fonts. Right now the
CSS falls back to Helvetica/Arial and Georgia, which is safe but not exact. To get the
real typefaces on the deployed site:

1. Drop the licensed `.woff2` files in `assets/fonts/`.
2. Uncomment the `@font-face` block at the top of `index.html`'s `<style>`.

Don't link to third-party "Hauora Sans" webfont CDNs — that's a similarly-named
open-source lookalike, not the brand's licensed font.

## Files

```
index.html
assets/
  reve-logo-white.png     — header logo (from Design System project)
  favicon-16.png
  favicon-32.png
  apple-touch-icon.png
```

Single self-contained page, no build step — drop the folder into your repo root and
it's ready for Vercel as a static deploy.
